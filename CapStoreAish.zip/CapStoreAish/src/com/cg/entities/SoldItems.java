package com.cg.entities;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class SoldItems implements Serializable{

	@Id
	@GeneratedValue
	private int soldItemId;
	@OneToOne
	@JoinColumn(name="customer")
	private Customer customer;
	@OneToOne
	@JoinColumn(name="inventory")
	private Inventory inventory;
	private String feedback;
	private LocalDate soldDate;
	private String status;
	private Date exceptedDate;
	private int quantity;
	private int returned;
	
	/* SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  */
	/*
	   SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
	    Date date = new Date();  
	  //  System.out.println(formatter.format(date));  
*/	    
	    
	public int getReturned() {
		return returned;
	}
	public void setReturned(int returned) {
		this.returned = returned;
	}
	public int getSoldItemId() {
		return soldItemId;
	}
	public void setSoldItemId(int soldItemId) {
		this.soldItemId = soldItemId;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Inventory getInventory() {
		return inventory;
	}
	public void setInventory(Inventory inventory) {
		this.inventory = inventory;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	public LocalDate getSoldDate() {
		return soldDate;
	}
	public void setSoldDate(LocalDate soldDate) {
		this.soldDate = soldDate; 
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getExceptedDate() {
		return exceptedDate;
	}
	public void setExceptedDate(Date exceptedDate) {
		this.exceptedDate = exceptedDate;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public SoldItems(Customer customer, Inventory inventory, String feedback, LocalDate soldDate, String status,
			Date exceptedDate, int quantity) {
		super();
		this.customer = customer;
		this.inventory = inventory;
		this.feedback = feedback;
		this.soldDate = soldDate;
		this.status = status;
		this.exceptedDate = exceptedDate;
		this.quantity = quantity;
	}
	public SoldItems() {
		super();
	}
	
	
	
	
	
}
