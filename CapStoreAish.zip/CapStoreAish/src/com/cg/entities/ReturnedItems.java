package com.cg.entities;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class ReturnedItems {

	@Id
	@GeneratedValue
	private int returnedId;
	private LocalDate returnedDate;
	
	
	
	@OneToOne
	@JoinColumn(name="solditemid")
	private SoldItems soldItems;

	public int getReturnedId() {
		return returnedId;
	}

	public void setReturnedId(int returnedId) {
		this.returnedId = returnedId;
	}

	public LocalDate getReturnedDate() {
		return returnedDate;
	}

	public void setReturnedDate(LocalDate returnedDate) {
		this.returnedDate =returnedDate;
	}

	public SoldItems getSoldItems() {
		return soldItems;
	}

	public void setSoldItems(SoldItems soldItems) {
		this.soldItems = soldItems;
	}

	public ReturnedItems( LocalDate returnedDate, SoldItems soldItems) {
		super();
		this.returnedDate = returnedDate;
		this.soldItems = soldItems;
	}

	public ReturnedItems() {
		super();
	}
	
	
	
}
