package com.cg.dao;

import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.format.datetime.joda.LocalDateParser;
import org.springframework.stereotype.Repository;

import com.cg.entities.Admin;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;
import com.cg.entities.ReturnedItems;
import com.cg.entities.SoldItems;



@Repository
public class CapgDAOImpl implements CapgDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	

	@Override
	public void plp() {
		Admin admin=new Admin("griet", "griet@gmail.com", "asdd");
	     Customer customer=new Customer("dfjhb@gmail.com", "ddfdf", "fead", "fewre");
	     Merchant merchant=new Merchant("afefq", "qer", "eefewf", "efqf", 1.00, 200.0);
	     Inventory inventory=new Inventory("qqede", 50, 200.00, "edeq", 0.00);
	     
	     //SoldItems items=new SoldItems("erqwr", new Date(), false, null, 120.00);
	     inventory.setMerchant(merchant);
	     customer.setCart(inventory);
	     SoldItems items=new SoldItems();
	     items.setCustomer(customer);
	     items.setInventory(inventory);
	     items.setFeedback("fer");
	     items.setSoldDate(LocalDate.of(2019,Month.MARCH,10));

	    
	     
	     
	       /* DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d-MMM-yyyy");
	        
			String date = "16-Aug-2016";

	        LocalDate localDate = LocalDate.parse(date, formatter);*/
	    ReturnedItems returnitems=new ReturnedItems(LocalDate.now(), items);
	     //customer.setCart(inventory);
	     //customer.setWishList(inventory);
	     entityManager.persist(admin);
	     entityManager.persist(merchant);
	     entityManager.persist(inventory);
	     entityManager.persist(customer);
	     entityManager.persist(items);
	    entityManager.persist(returnitems);
	     //entityManager.persist(items);
	     entityManager.flush();
	     entityManager.close();
		
	}
	
	/*LocalDate start = LocalDate.of(1947,Month.AUGUST,15);
		LocalDate end = LocalDate.now();
		
		Period period = start.until(end);
		
		System.out.println("Days:"+ period.getDays());
*/	
	

	@Override
	public Merchant updateInventory(int soldItemId, LocalDate date) 
	{
		SoldItems soldItem=entityManager.find(SoldItems.class, soldItemId);
		/*int mId=soldItem.getInventory().getMerchant().getMerchantId();
		System.out.println(mId);*/
		int inventoryId = soldItem.getInventory().getInventoryId();
		

		Inventory inventory =entityManager.find(Inventory.class, inventoryId);
		
		Inventory inventoryUpdated = inventory;
		inventoryUpdated.setQuantity(inventory.getQuantity()+1);
		entityManager.persist(inventoryUpdated);
		entityManager.remove(soldItem);
		entityManager.flush();
		return null;
	
	}


	@Override
	public List<SoldItems> loadSoldItems() {
		// TODO Auto-generated method stub
		TypedQuery<SoldItems> typedQuery = entityManager.createQuery("select s from SoldItems s", SoldItems.class);
		return typedQuery.getResultList();
	}



	

	
	
/*
	@Override
	public void save(Inventory inventory) {
		entityManager.persist(inventory);
		entityManager.flush();
	}

	@Override
	public String find(int i) {
		Inventory inventory=entityManager.find(Inventory.class,i);
		return inventory.getFileName();
	}

	@Override
	public String retrievePassword(String emailId) {
		//TypedQuery<Admin> query=entityManager.createQuery("select a from Admin a where a.emailId="+emailId, Admin.class);
		String selectQuery = "from Admin a where a.emailId=:emailId";
		Query query = entityManager.createQuery(selectQuery);
		query.setParameter("emailId", emailId);
		List<Admin> admins=query.getResultList();
		return admins.get(0).getPassword();
	}
*/
	
}
