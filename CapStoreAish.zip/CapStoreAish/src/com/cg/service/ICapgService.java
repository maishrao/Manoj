package com.cg.service;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import com.cg.entities.Inventory;
import com.cg.entities.Merchant;
import com.cg.entities.SoldItems;

public interface ICapgService {

	// List<QueryAnswers> getall();
void plp();
/*
void save(Inventory inventory);*/

/*String find(int i);

String retrievePassword(String emailId);*/



public abstract Merchant updateInventory(int soldItemId, LocalDate date);
public abstract List<SoldItems> loadSoldItems();


}
