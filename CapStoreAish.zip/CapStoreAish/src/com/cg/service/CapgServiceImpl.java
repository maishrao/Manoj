package com.cg.service;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.CapgDAO;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;
import com.cg.entities.SoldItems;

@Service
@Transactional
public class CapgServiceImpl implements ICapgService {

	@Autowired
	CapgDAO iQueryDAO;
	
	@Override
	public void plp() {
		iQueryDAO.plp();
	}
	
	
	

	@Override
	public Merchant updateInventory(int soldItemId, LocalDate date) {
	
	return iQueryDAO.updateInventory(soldItemId, date);			
	}

	@Override
	public List<SoldItems> loadSoldItems() {
		// TODO Auto-generated method stub
		return iQueryDAO.loadSoldItems();
	}


	
	

	

/*	@Override
	public void save(Inventory inventory) {
		iQueryDAO.save(inventory);
		
	}*/

	/*@Override
	public String find(int i) {
		return iQueryDAO.find(i);
	}

	@Override
	public String retrievePassword(String emailId) {
		return iQueryDAO.retrievePassword(emailId);
	}
*/
	
}
